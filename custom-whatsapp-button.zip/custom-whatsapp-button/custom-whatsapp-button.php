<?php
/*
Plugin Name: Custom WhatsApp Button
Description: Adds a WhatsApp chat button to your website.
Version: 1.0
Author: Your Name
*/

function enqueue_whatsapp_script() {
    wp_enqueue_script('whatsapp-script', plugin_dir_url(__FILE__) . 'whatsapp-script.js', array('jquery'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'enqueue_whatsapp_script');
