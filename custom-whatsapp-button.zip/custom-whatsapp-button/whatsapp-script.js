document.addEventListener('DOMContentLoaded', function () {
    var whatsappButton = document.createElement('div');
    whatsappButton.innerHTML = 'WhatsApp Chat';
    whatsappButton.style.cssText = 'position: fixed; bottom: 20px; right: 20px; background-color: green; color: white; padding: 10px; cursor: pointer;';
    whatsappButton.onclick = function () {
        // Add your WhatsApp chat logic here
        // For example, open the WhatsApp link in a new tab
        window.open('https://api.whatsapp.com/send?phone=YOUR_PHONE_NUMBER', '_blank');
    };

    document.body.appendChild(whatsappButton);
});
